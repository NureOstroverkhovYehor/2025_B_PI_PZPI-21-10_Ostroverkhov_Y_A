package plantlightcycle.services;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import plantlightcycle.dto.EditLightLevelForAllAttachedLampsToSensorDto;
import plantlightcycle.models.SensorEntity;

/**
 * Service for managing light levels based on sensor readings.
 */
@Service
@RequiredArgsConstructor
public class LightService {
    /**
     * RestTemplate for making HTTP requests to the backend API.
     */
    private final RestTemplate restTemplate;
    private final AuthService authService;

    /**
     * Adjusts the light level based on the sensor reading value.
     * If the value is outside the appropriate range, the light level is changed.
     *
     * @param value  The current reading value from the sensor.
     * @param sensor The sensor entity containing information about the sensor and light levels.
     */
    public void changeLightCorrespondingToWarning(int value, SensorEntity sensor) {
        int newLightLevel;
        if (value > sensor.getMaxLightLevel()) {
            newLightLevel = sensor.getMaxLightLevel();
        } else {
            newLightLevel = sensor.getMinLightLevel();
        }

        String jwt = authService.getToken();

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(jwt);
        HttpEntity<EditLightLevelForAllAttachedLampsToSensorDto> request = new HttpEntity<>(new EditLightLevelForAllAttachedLampsToSensorDto(newLightLevel), headers);
        restTemplate.postForEntity("http://localhost:8080/sensors/" + sensor.getId(), request, String.class);
        System.out.println("Lamp change dto sent successfully");
    }
}