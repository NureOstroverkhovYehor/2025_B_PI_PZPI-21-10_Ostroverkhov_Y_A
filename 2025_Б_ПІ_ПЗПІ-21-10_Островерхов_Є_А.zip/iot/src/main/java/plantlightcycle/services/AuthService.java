package plantlightcycle.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import plantlightcycle.dto.AuthenticationRequestDto;

/**
 * Service for authorization
 */
@Service
@RequiredArgsConstructor
public class AuthService {

    private final RestTemplate restTemplate;

    private String jwtToken;

    /**
     * Device name.
     */
    @Value("${deviceName}")
    private String deviceName;

    /**
     * Device password.
     */
    @Value("${devicePassword}")
    private String devicePassword;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public String getToken() {
        if (jwtToken == null) {
            try {
                authenticate();
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }
        return jwtToken;
    }

    private void authenticate() throws JsonProcessingException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        AuthenticationRequestDto loginEntity = new AuthenticationRequestDto(deviceName, devicePassword);

        ResponseEntity<String> response = restTemplate.postForEntity(
                "http://localhost:8080/login",
                new HttpEntity<>(objectMapper.writeValueAsString(loginEntity), headers),
                String.class
        );

        if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
            jwtToken = objectMapper.readTree(response.getBody())
                    .get("token")
                    .asText();
            System.out.println("Authenticated successfully.");
        } else {
            throw new RuntimeException("Authentication failed: " + response.getStatusCode());
        }
    }

    public void clearToken() {
        this.jwtToken = null;
    }
}
