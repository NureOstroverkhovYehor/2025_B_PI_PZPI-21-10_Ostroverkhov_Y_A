package plantlightcycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantLightcycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlantLightcycleApplication.class, args);
	}

}
