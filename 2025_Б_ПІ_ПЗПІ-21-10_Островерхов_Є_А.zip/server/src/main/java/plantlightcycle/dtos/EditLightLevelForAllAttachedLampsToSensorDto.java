package plantlightcycle.dtos;

/**
 * A data transfer object (DTO) representing the request to edit all lamps.
 */
public record EditLightLevelForAllAttachedLampsToSensorDto(Integer newValue) {
    // No constructor needed, record automatically provides a constructor
    // Parameter:
    // - newValue: the new light level value to set for the lamps
}