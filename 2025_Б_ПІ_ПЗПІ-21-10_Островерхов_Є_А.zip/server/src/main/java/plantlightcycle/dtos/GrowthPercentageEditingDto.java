package plantlightcycle.dtos;

public record GrowthPercentageEditingDto(Long plantId, Integer newPercentageValue) {
}
