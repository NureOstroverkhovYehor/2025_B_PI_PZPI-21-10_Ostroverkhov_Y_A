package plantlightcycle.dtos;

import plantlightcycle.models.Role;

public record RoleDto (Role role) {
}
