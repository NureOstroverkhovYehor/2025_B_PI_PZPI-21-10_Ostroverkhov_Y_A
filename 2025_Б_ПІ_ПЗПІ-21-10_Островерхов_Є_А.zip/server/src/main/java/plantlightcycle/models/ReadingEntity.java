package plantlightcycle.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Represents a reading entity captured by a sensor.
 * This class defines attributes and methods related to readings.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class ReadingEntity {
    /**
     * Unique identifier for the reading entity.
     */
    @Id
    @GeneratedValue
    private Long id;

    /**
     * The sensor associated with this reading.
     */
    @ManyToOne
    @JsonIgnore
    private SensorEntity sensor;

    /**
     * Name associated with the reading.
     */
    private String name;

    /**
     * Value of the reading.
     */
    private Integer readingValue;

    /**
     * Date and time when the reading was captured.
     */
    private LocalDateTime dateTime;

    /**
     * Indicates whether the reading is a warning.
     */
    private Boolean isWarning;

    /**
     * Constructs a ReadingEntity object with specified parameters.
     *
     * @param name      The name associated with the reading.
     * @param readingValue     The value of the reading.
     * @param isWarning Indicates whether the reading is a warning.
     */
    public ReadingEntity(String name, Integer readingValue, Boolean isWarning) {
        this.name = name;
        this.readingValue = readingValue;
        this.isWarning = isWarning;
        this.dateTime = LocalDateTime.now();
    }

    /**
     * Checks if the reading is a warning.
     *
     * @return True if the reading is a warning, false otherwise.
     */
    @JsonIgnore
    public boolean isWarning() {
        return isWarning;
    }
}
