package plantlightcycle.controllers;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import plantlightcycle.dtos.DeletionSensorDto;
import plantlightcycle.dtos.EditLightLevelForAllAttachedLampsToSensorDto;
import plantlightcycle.dtos.SensorDto;
import plantlightcycle.models.LampEntity;
import plantlightcycle.models.SensorEntity;
import plantlightcycle.services.LampService;
import plantlightcycle.services.SensorService;

import java.util.List;
import java.util.Set;

/**
 * Controller handling sensor-related endpoints.
 */
@RestController
@RequestMapping("/sensors")
@RequiredArgsConstructor
public class SensorController {
    /**
     * Service responsible for sensor-related operations.
     */
    private final SensorService sensorService;

    /**
     * Service responsible for lamp-related operations.
     */
    private final LampService lampService;

    @GetMapping
    public ResponseEntity<List<SensorEntity>> getAllSensors() {
        return ResponseEntity.ok(sensorService.getAllSensors());
    }

    /**
     * Retrieves all sensors associated with a particular plant.
     *
     * @param plantId Plant ID
     * @return ResponseEntity containing a list of SensorEntity associated with the plant
     */
    @GetMapping("/{plantId}")
    public ResponseEntity<List<SensorEntity>> getAllPlantSensors(@PathVariable Long plantId) {
        return ResponseEntity.ok(sensorService.getAllSensorsByPlantId(plantId));
    }

    /**
     * Saves a new sensor.
     *
     * @param sensorDto Sensor information to be saved
     * @return ResponseEntity containing a set of all SensorEntity corresponding to the plant
     * and HTTP status CREATED
     */
    @PostMapping
    public ResponseEntity<Set<SensorEntity>> saveSensor(@RequestBody SensorDto sensorDto) {
        return new ResponseEntity<>(sensorService.saveSensor(sensorDto), HttpStatus.CREATED);
    }

    /**
     * Updates light level for all sensor's lamps.
     *
     * @param id Sensor ID
     * @param lightLevelDto new light level information
     * @return ResponseEntity containing an information about updated lamps
     * and HTTP status OK
     */
    @PostMapping("/{id}")
    public ResponseEntity<List<LampEntity>> saveSensor(@PathVariable Long id, @RequestBody EditLightLevelForAllAttachedLampsToSensorDto lightLevelDto) {
        return ResponseEntity.ok(lampService.updateLightLevelForAttachedLamps(id, lightLevelDto));
    }

    /**
     * Deletes a sensor from a plant's list of sensors.
     *
     * @param deletionSensorDto Information about the sensor to be deleted from the plant
     * @return ResponseEntity with all sensors retrieved by plant ID
     */
    @DeleteMapping
    public ResponseEntity<List<SensorEntity>> deleteSensorFromPlant(@RequestBody DeletionSensorDto deletionSensorDto) {
        sensorService.deleteSensorFromPlant(deletionSensorDto);
        return ResponseEntity.ok(sensorService.getAllSensorsByPlantId(deletionSensorDto.plantId()));
    }
}
